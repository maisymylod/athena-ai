"""
Athena Image Monitor — Web Scanning Pipeline
=============================================

Scans the web for potential non-consensual synthetic imagery using
perceptual hashing (pHash) and reverse-image similarity matching.

This is a proof-of-concept tool demonstrating Athena's core monitoring
pipeline. It crawls publicly accessible image URLs, computes perceptual
hashes, and compares them against a set of protected identity reference
images to detect potential deepfake matches.

Usage:
    python monitor.py --refs ./reference_images/ --urls urls.txt
    python monitor.py --refs ./reference_images/ --url https://example.com
    python monitor.py --demo

Requirements:
    pip install pillow imagehash requests beautifulsoup4
"""

import argparse
import hashlib
import json
import os
import sys
import time
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional
from urllib.parse import urljoin, urlparse

try:
    import imagehash
    from PIL import Image
    HAS_IMAGEHASH = True
except ImportError:
    HAS_IMAGEHASH = False

try:
    import requests
    from bs4 import BeautifulSoup
    HAS_REQUESTS = True
except ImportError:
    HAS_REQUESTS = False


# ──────────────────────────────────────────────
# Data Models
# ──────────────────────────────────────────────

@dataclass
class ScanResult:
    """Result of scanning a single image URL."""
    url: str
    timestamp: str
    phash: Optional[str] = None
    similarity_score: float = 0.0
    matched_reference: Optional[str] = None
    is_potential_match: bool = False
    is_synthetic_suspect: bool = False
    error: Optional[str] = None


@dataclass
class ScanReport:
    """Aggregate report from a monitoring scan."""
    scan_id: str
    started_at: str
    completed_at: Optional[str] = None
    total_images_scanned: int = 0
    potential_matches: int = 0
    synthetic_suspects: int = 0
    results: list = field(default_factory=list)
    reference_hashes: dict = field(default_factory=dict)


# ──────────────────────────────────────────────
# Perceptual Hashing Engine
# ──────────────────────────────────────────────

class PerceptualHasher:
    """
    Computes and compares perceptual hashes for images.

    Uses pHash (DCT-based) which is robust to:
    - Resizing
    - Minor color adjustments
    - JPEG compression artifacts
    - Small crops

    This is key for detecting nudified images that retain
    the victim's face while altering the body.
    """

    SIMILARITY_THRESHOLD = 12  # Hamming distance; lower = more similar

    def compute_phash(self, image_path: str) -> Optional[str]:
        """Compute perceptual hash of an image file."""
        if not HAS_IMAGEHASH:
            return self._fallback_hash(image_path)
        try:
            img = Image.open(image_path)
            phash = imagehash.phash(img, hash_size=16)
            return str(phash)
        except Exception as e:
            print(f"  [!] Error hashing {image_path}: {e}")
            return None

    def compute_phash_from_bytes(self, img_bytes: bytes) -> Optional[str]:
        """Compute perceptual hash from raw image bytes."""
        if not HAS_IMAGEHASH:
            return hashlib.md5(img_bytes).hexdigest()[:16]
        try:
            from io import BytesIO
            img = Image.open(BytesIO(img_bytes))
            phash = imagehash.phash(img, hash_size=16)
            return str(phash)
        except Exception as e:
            print(f"  [!] Error hashing image bytes: {e}")
            return None

    def hamming_distance(self, hash1: str, hash2: str) -> int:
        """Compute Hamming distance between two hex hash strings."""
        if not HAS_IMAGEHASH:
            # Fallback: simple character comparison
            return sum(c1 != c2 for c1, c2 in zip(hash1, hash2))
        try:
            h1 = imagehash.hex_to_hash(hash1)
            h2 = imagehash.hex_to_hash(hash2)
            return h1 - h2
        except Exception:
            return 999

    def is_similar(self, hash1: str, hash2: str) -> tuple[bool, float]:
        """
        Check if two images are perceptually similar.
        Returns (is_match, similarity_score).

        Similarity score is normalized 0-1 where 1 = identical.
        """
        distance = self.hamming_distance(hash1, hash2)
        max_distance = 256  # 16x16 hash
        similarity = max(0, 1 - (distance / max_distance))
        is_match = distance <= self.SIMILARITY_THRESHOLD
        return is_match, round(similarity, 4)

    def _fallback_hash(self, image_path: str) -> Optional[str]:
        """MD5-based fallback when imagehash isn't installed."""
        try:
            with open(image_path, 'rb') as f:
                return hashlib.md5(f.read()).hexdigest()[:16]
        except Exception:
            return None


# ──────────────────────────────────────────────
# Synthetic Image Analyzer (Stub)
# ──────────────────────────────────────────────

class SyntheticAnalyzer:
    """
    Analyzes images for signs of AI generation.

    PRODUCTION NOTE: This is a stub for the MVP. The full implementation
    will use a fine-tuned ConvNeXt/EfficientNet model trained on output
    from the top nudify tools to detect GAN/diffusion artifacts:
    - Frequency domain anomalies (DCT spectral analysis)
    - Inconsistent noise patterns
    - Skin texture irregularities
    - Boundary artifacts around face/body regions

    For now, this returns a placeholder confidence score.
    """

    def analyze(self, image_path: str) -> dict:
        """
        Analyze an image for synthetic generation indicators.

        Returns:
            dict with keys:
                - is_suspect: bool
                - confidence: float (0-1)
                - method: str describing detection approach
                - details: str with findings
        """
        # TODO: Replace with trained model inference
        # For MVP, perform basic metadata/statistical checks

        result = {
            "is_suspect": False,
            "confidence": 0.0,
            "method": "metadata_heuristic",
            "details": ""
        }

        try:
            img = Image.open(image_path)

            # Check 1: EXIF data — AI-generated images typically lack EXIF
            exif = img.getexif()
            has_exif = len(exif) > 0

            # Check 2: Image dimensions — nudify tools often output
            # specific resolutions (512x512, 768x1024, etc.)
            w, h = img.size
            suspicious_dims = (
                (w == 512 and h == 512) or
                (w == 768 and h == 1024) or
                (w == 1024 and h == 1024) or
                (w == 1024 and h == 768)
            )

            # Check 3: Color space anomalies
            mode = img.mode

            signals = []
            if not has_exif:
                signals.append("no_exif_data")
            if suspicious_dims:
                signals.append(f"suspicious_dimensions_{w}x{h}")

            if len(signals) >= 2:
                result["is_suspect"] = True
                result["confidence"] = 0.45
                result["details"] = f"Heuristic flags: {', '.join(signals)}"
            elif len(signals) == 1:
                result["confidence"] = 0.2
                result["details"] = f"Minor flag: {signals[0]}"
            else:
                result["details"] = "No synthetic indicators found via heuristics"

        except Exception as e:
            result["details"] = f"Analysis error: {e}"

        return result


# ──────────────────────────────────────────────
# Web Scraper / Image Crawler
# ──────────────────────────────────────────────

class ImageCrawler:
    """
    Crawls web pages and extracts image URLs for scanning.

    Designed to be pointed at known deepfake hosting sites,
    image boards, and social platforms.
    """

    SUPPORTED_EXTENSIONS = {'.jpg', '.jpeg', '.png', '.webp', '.gif', '.bmp'}
    USER_AGENT = "Athena-Monitor/0.1 (deepfake-protection; contact@athena.ai)"

    def __init__(self):
        if not HAS_REQUESTS:
            print("[!] 'requests' and 'beautifulsoup4' required for web crawling.")
            print("    Install: pip install requests beautifulsoup4")

    def extract_image_urls(self, page_url: str) -> list[str]:
        """Extract all image URLs from a web page."""
        if not HAS_REQUESTS:
            return []

        try:
            headers = {"User-Agent": self.USER_AGENT}
            resp = requests.get(page_url, headers=headers, timeout=15)
            resp.raise_for_status()

            soup = BeautifulSoup(resp.text, 'html.parser')
            image_urls = []

            # <img> tags
            for img in soup.find_all('img'):
                src = img.get('src') or img.get('data-src')
                if src:
                    full_url = urljoin(page_url, src)
                    if self._is_image_url(full_url):
                        image_urls.append(full_url)

            # <a> tags linking to images
            for a in soup.find_all('a', href=True):
                href = a['href']
                full_url = urljoin(page_url, href)
                if self._is_image_url(full_url):
                    image_urls.append(full_url)

            return list(set(image_urls))

        except Exception as e:
            print(f"  [!] Error crawling {page_url}: {e}")
            return []

    def download_image(self, url: str, output_dir: str) -> Optional[str]:
        """Download an image and return the local file path."""
        if not HAS_REQUESTS:
            return None

        try:
            headers = {"User-Agent": self.USER_AGENT}
            resp = requests.get(url, headers=headers, timeout=15, stream=True)
            resp.raise_for_status()

            content_type = resp.headers.get('content-type', '')
            if 'image' not in content_type:
                return None

            # Create filename from URL hash
            url_hash = hashlib.md5(url.encode()).hexdigest()[:12]
            ext = Path(urlparse(url).path).suffix or '.jpg'
            filename = f"{url_hash}{ext}"
            filepath = os.path.join(output_dir, filename)

            with open(filepath, 'wb') as f:
                for chunk in resp.iter_content(8192):
                    f.write(chunk)

            return filepath

        except Exception as e:
            print(f"  [!] Error downloading {url}: {e}")
            return None

    def _is_image_url(self, url: str) -> bool:
        """Check if URL likely points to an image."""
        parsed = urlparse(url)
        ext = Path(parsed.path).suffix.lower()
        return ext in self.SUPPORTED_EXTENSIONS


# ──────────────────────────────────────────────
# Takedown Request Generator
# ──────────────────────────────────────────────

class TakedownGenerator:
    """
    Generates TAKE IT DOWN Act-compliant takedown requests.

    The TAKE IT DOWN Act (signed May 2025) requires platforms to remove
    non-consensual intimate imagery within 48 hours of a victim's report.
    This tool automates the generation of compliant takedown notices.
    """

    TEMPLATE = """
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
TAKEDOWN REQUEST — TAKE IT DOWN ACT COMPLIANCE
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Date:           {date}
Reference ID:   {ref_id}

TO: {platform} Content Moderation / Trust & Safety

RE: Removal of Non-Consensual Synthetic Intimate Imagery

I am writing to request the immediate removal of non-consensual
synthetic intimate imagery (NCII) pursuant to the TAKE IT DOWN Act
(Public Law, signed May 19, 2025), which requires covered platforms
to remove reported NCII within 48 hours of receipt of this notice.

CONTENT LOCATION:
  URL: {url}

EVIDENCE OF SYNTHETIC ORIGIN:
  Detection Method:  {method}
  Confidence Score:  {confidence}
  Perceptual Hash:   {phash}
  Scan Timestamp:    {scan_time}

This image has been identified as AI-generated/manipulated intimate
imagery created without the consent of the depicted individual.

Under the TAKE IT DOWN Act, you are required to:
  1. Remove the identified content within 48 hours
  2. Make reasonable efforts to prevent re-upload
  3. Provide confirmation of removal

Forensic evidence and cryptographic provenance records are available
upon request. Failure to comply may result in enforcement action
under the Act.

Generated by Athena (athena.ai) — Automated NCII Protection
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
"""

    def generate(self, scan_result: ScanResult, platform: str = "Platform") -> str:
        """Generate a takedown request for a matched image."""
        return self.TEMPLATE.format(
            date=datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC"),
            ref_id=f"ATH-{hashlib.md5(scan_result.url.encode()).hexdigest()[:8].upper()}",
            platform=platform,
            url=scan_result.url,
            method="Perceptual hash match + synthetic analysis",
            confidence=f"{scan_result.similarity_score:.1%}",
            phash=scan_result.phash or "N/A",
            scan_time=scan_result.timestamp
        )


# ──────────────────────────────────────────────
# Monitor (Main Orchestrator)
# ──────────────────────────────────────────────

class AthenaMonitor:
    """
    Main monitoring pipeline that ties everything together.

    1. Load reference images (protected identities)
    2. Crawl target URLs for images
    3. Compare found images against reference hashes
    4. Flag potential matches for review
    5. Generate takedown requests for confirmed matches
    """

    def __init__(self, reference_dir: Optional[str] = None):
        self.hasher = PerceptualHasher()
        self.analyzer = SyntheticAnalyzer()
        self.crawler = ImageCrawler()
        self.takedown = TakedownGenerator()
        self.reference_hashes = {}

        if reference_dir and os.path.isdir(reference_dir):
            self._load_references(reference_dir)

    def _load_references(self, ref_dir: str):
        """Load and hash all reference images."""
        print(f"\n[*] Loading reference images from {ref_dir}")
        for fname in os.listdir(ref_dir):
            fpath = os.path.join(ref_dir, fname)
            if Path(fname).suffix.lower() in ImageCrawler.SUPPORTED_EXTENSIONS:
                phash = self.hasher.compute_phash(fpath)
                if phash:
                    self.reference_hashes[fname] = phash
                    print(f"  [+] {fname} -> {phash}")

        print(f"  [{len(self.reference_hashes)} reference images loaded]\n")

    def scan_url(self, page_url: str, tmp_dir: str = "/tmp/athena_scan") -> list[ScanResult]:
        """Scan a single page URL for matching images."""
        os.makedirs(tmp_dir, exist_ok=True)
        results = []

        print(f"[*] Crawling: {page_url}")
        image_urls = self.crawler.extract_image_urls(page_url)
        print(f"  [+] Found {len(image_urls)} images")

        for img_url in image_urls:
            result = ScanResult(
                url=img_url,
                timestamp=datetime.now(timezone.utc).isoformat()
            )

            # Download
            local_path = self.crawler.download_image(img_url, tmp_dir)
            if not local_path:
                result.error = "download_failed"
                results.append(result)
                continue

            # Hash
            phash = self.hasher.compute_phash(local_path)
            result.phash = phash

            if phash:
                # Compare against all references
                for ref_name, ref_hash in self.reference_hashes.items():
                    is_match, similarity = self.hasher.is_similar(phash, ref_hash)
                    if is_match or similarity > result.similarity_score:
                        result.similarity_score = similarity
                        if is_match:
                            result.is_potential_match = True
                            result.matched_reference = ref_name
                            print(f"  [!] MATCH: {img_url}")
                            print(f"      Reference: {ref_name} | Similarity: {similarity:.2%}")

            # Synthetic analysis
            analysis = self.analyzer.analyze(local_path)
            if analysis["is_suspect"]:
                result.is_synthetic_suspect = True

            # Cleanup
            try:
                os.remove(local_path)
            except OSError:
                pass

            results.append(result)

        return results

    def run_scan(self, urls: list[str]) -> ScanReport:
        """Run a full monitoring scan across multiple URLs."""
        report = ScanReport(
            scan_id=hashlib.md5(str(time.time()).encode()).hexdigest()[:12],
            started_at=datetime.now(timezone.utc).isoformat(),
            reference_hashes=dict(self.reference_hashes)
        )

        for url in urls:
            results = self.scan_url(url)
            report.results.extend(results)

        report.completed_at = datetime.now(timezone.utc).isoformat()
        report.total_images_scanned = len(report.results)
        report.potential_matches = sum(1 for r in report.results if r.is_potential_match)
        report.synthetic_suspects = sum(1 for r in report.results if r.is_synthetic_suspect)

        return report

    def demo(self):
        """Run a demonstration with synthetic test data."""
        print("=" * 60)
        print("  ATHENA IMAGE MONITOR — DEMO MODE")
        print("  Protecting women & girls from deepfake abuse")
        print("=" * 60)

        # Create mock reference
        print("\n[*] Demo: Simulating identity monitoring pipeline\n")

        mock_results = [
            ScanResult(
                url="https://example-site.com/images/img_0847.jpg",
                timestamp=datetime.now(timezone.utc).isoformat(),
                phash="a3c7e1f09b2d4e68",
                similarity_score=0.94,
                matched_reference="protected_user_ref_01.jpg",
                is_potential_match=True,
                is_synthetic_suspect=True
            ),
            ScanResult(
                url="https://example-site.com/images/img_1293.jpg",
                timestamp=datetime.now(timezone.utc).isoformat(),
                phash="f7b2c8a1d5e34907",
                similarity_score=0.12,
                is_potential_match=False,
                is_synthetic_suspect=False
            ),
            ScanResult(
                url="https://example-site.com/images/img_2041.jpg",
                timestamp=datetime.now(timezone.utc).isoformat(),
                phash="b8d4f2a6c1e57039",
                similarity_score=0.87,
                matched_reference="protected_user_ref_01.jpg",
                is_potential_match=True,
                is_synthetic_suspect=True
            ),
        ]

        print("[*] Scan Results:")
        print("-" * 60)
        for r in mock_results:
            status = "🚨 MATCH" if r.is_potential_match else "✓ Clear"
            synth = " [SYNTHETIC]" if r.is_synthetic_suspect else ""
            print(f"  {status}{synth}")
            print(f"    URL:        {r.url}")
            print(f"    Similarity: {r.similarity_score:.0%}")
            if r.matched_reference:
                print(f"    Matched:    {r.matched_reference}")
            print()

        # Generate takedown for matches
        matches = [r for r in mock_results if r.is_potential_match]
        if matches:
            print(f"\n[*] Generating {len(matches)} TAKE IT DOWN Act takedown request(s)...")
            print()
            for match in matches:
                takedown = self.takedown.generate(match, platform="Example Platform Inc.")
                print(takedown)

        # Summary
        print("=" * 60)
        print("  SCAN SUMMARY")
        print("=" * 60)
        print(f"  Images scanned:      {len(mock_results)}")
        print(f"  Potential matches:    {len(matches)}")
        print(f"  Synthetic suspects:   {sum(1 for r in mock_results if r.is_synthetic_suspect)}")
        print(f"  Takedowns generated:  {len(matches)}")
        print(f"  Scan time:           {datetime.now(timezone.utc).isoformat()}")
        print("=" * 60)


# ──────────────────────────────────────────────
# CLI
# ──────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="Athena Image Monitor — Deepfake detection & takedown automation",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python monitor.py --demo
  python monitor.py --refs ./my_photos/ --url https://example.com
  python monitor.py --refs ./my_photos/ --urls watchlist.txt

Built by Athena (athena.ai) — Protecting women & girls from deepfake abuse.
        """
    )

    parser.add_argument('--demo', action='store_true',
                        help='Run demonstration with synthetic data')
    parser.add_argument('--refs', type=str,
                        help='Directory containing reference/protected images')
    parser.add_argument('--url', type=str,
                        help='Single URL to scan')
    parser.add_argument('--urls', type=str,
                        help='Text file with one URL per line')
    parser.add_argument('--output', type=str, default='scan_report.json',
                        help='Output report filename (default: scan_report.json)')

    args = parser.parse_args()

    if args.demo:
        monitor = AthenaMonitor()
        monitor.demo()
        return

    if not args.refs:
        parser.error("--refs is required (path to reference images directory)")

    monitor = AthenaMonitor(reference_dir=args.refs)

    urls = []
    if args.url:
        urls.append(args.url)
    if args.urls:
        with open(args.urls) as f:
            urls.extend(line.strip() for line in f if line.strip())

    if not urls:
        parser.error("Provide --url or --urls to scan")

    report = monitor.run_scan(urls)

    # Save report
    with open(args.output, 'w') as f:
        json.dump(asdict(report), f, indent=2)

    print(f"\n{'='*60}")
    print(f"  SCAN COMPLETE")
    print(f"{'='*60}")
    print(f"  Images scanned:     {report.total_images_scanned}")
    print(f"  Potential matches:  {report.potential_matches}")
    print(f"  Synthetic suspects: {report.synthetic_suspects}")
    print(f"  Report saved to:    {args.output}")
    print(f"{'='*60}")


if __name__ == "__main__":
    main()
